# Under Construction

This is a simple HTML document with no external dependencies, designed to be used as a temporary home page.

## Usage

1. Edit `index.html` in order to change the `<title>` and the `<h1>`.
2. Optionally, modify the elements and the style according to your needs.
3. Upload the file to the root directory of your website, or [configure](https://help.github.com/articles/adding-or-removing-a-custom-domain-for-your-github-pages-site/) your GitHub Pages site.

## License

Licensed under the [MIT License](https://opensource.org/licenses/MIT).
